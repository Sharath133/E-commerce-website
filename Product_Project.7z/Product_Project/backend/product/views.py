from django.shortcuts import render
from rest_framework.decorators import api_view,parser_classes,permission_classes
from rest_framework.response import Response
from django.contrib.auth import authenticate
from rest_framework.authtoken.models  import Token
from django.contrib.auth.models import User
from rest_framework.permissions import AllowAny,IsAuthenticated,IsAdminUser,BasePermission
from .models import Product
from .serializers import *
from rest_framework.parsers import MultiPartParser,FormParser
from django.shortcuts import get_object_or_404
from rest_framework import viewsets
from rest_framework import generics, permissions,status
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth import login
from rest_framework.authtoken.serializers import AuthTokenSerializer
# from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.views import APIView
from rest_framework.authtoken.views import ObtainAuthToken
# Register API
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth import authenticate, login
from rest_framework.views import APIView



class WriteByAdminOnlyPermission(BasePermission):
    def has_permission(self, request, view):
        user=request.user
        if request.method == 'GET':
            return True
        
        if request.method == 'POST' or request.method == 'PUT' or request.method == 'DELETE' :
            if user.is_superuser :
                return True
            
        return False        

        
class RegisterAPI(generics.GenericAPIView):
    authentication_classes = []  # Remove session-based authentication
    permission_classes = [AllowAny]
    serializer_class = RegisterSerializer

    def post(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            user = serializer.save()

            token, _ = Token.objects.get_or_create(user=user)

            return Response(
                {
                    "user": UserSerializer(user, context=self.get_serializer_context()).data,
                    "token": token.key
                },
                status=status.HTTP_201_CREATED
            )
        except ObjectDoesNotExist:
            return Response({'message': 'Object does not exist'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({'message': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class LoginAPI(APIView):
    authentication_classes = []  # Remove session-based authentication
    permission_classes = [AllowAny]

    def post(self, request, format=None):
        serializer = AuthTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = authenticate(
            request,
            username=serializer.validated_data['username'],
            password=serializer.validated_data['password']
        )

        if user is not None:
            login(request, user)  # Officially log in the user

            token, _ = Token.objects.get_or_create(user=user)  # Create or retrieve the token

            return Response(
                {
                    "user": UserSerializer(user, context={'request': request}).data,
                    "token": token.key
                },
                status=status.HTTP_200_OK
            )
        else:
            return Response({"message": "Invalid username or password"}, status=status.HTTP_401_UNAUTHORIZED)


from django.db.models import Q

@api_view(['GET'])
@authentication_classes([TokenAuthentication])
@permission_classes([WriteByAdminOnlyPermission])
def getProducts(request):
    title_query = request.query_params.get('title')
    category_query = request.query_params.get('category')

    products = Product.objects.all()

    if title_query:
        products = products.filter(title__icontains=title_query)

    if category_query:
        products = products.filter(category__category__icontains=category_query)

    serializer = ProductSerializer(products, many=True)
    serializer_categories = categoriesSerializer(Category.objects.all(), many=True).data
    data = {
        'products': [],
        # 'categories': serializer_categories
    }

    for product in serializer.data:
        product_data = {
            'id': product['id'],
            'title': product['title'],
            **{key: value for key, value in product.items() if key != 'title'},
        }
        data['products'].append(product_data)

    response_data = {
        'data': data  # Include 'data' key in the response
    }

    return Response(response_data)



@api_view(['GET'])
@authentication_classes([TokenAuthentication])
@permission_classes([WriteByAdminOnlyPermission])
def getProduct(request, pk):
    try:
        product = Product.objects.get(pk=pk)
        serializer = ProductSerializer(product)
        serialized_category = categoriesSerializer(product.category).data
        data = {
            'product': serializer.data,
            'category': serialized_category
        }
        return Response(data)
    except Product.DoesNotExist:
        return Response({'message': 'Product does not exist'}, status=404)


from rest_framework.exceptions import ValidationError
@authentication_classes([TokenAuthentication])
@permission_classes([WriteByAdminOnlyPermission])
class ImageView(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    parser_classes = [MultiPartParser, FormParser]

    def clean_category_name(self, category_name):
    # If category_name is a list, take the first element
        if isinstance(category_name, list):
            category_name = category_name[0]

    # Remove square brackets and quotes from the category name
        if category_name:
            category_name = category_name.strip("[]").replace("'", "")

        return category_name

    def create(self, request, *args, **kwargs):
        product_data = request.data.copy()
        category_name = self.clean_category_name(product_data.pop('category', None))  # Extract category name from request data

        product_serializer = ProductSerializer(data=product_data)
        if product_serializer.is_valid():
            product_instance = product_serializer.save()

            if category_name:
                category, _ = Category.objects.get_or_create(category=category_name)
                product_instance.category = category
                product_instance.save()

            return Response(product_serializer.data, status=status.HTTP_201_CREATED)

        return Response(product_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        product_instance = self.get_object()
        product_data = request.data.copy()
        category_name = self.clean_category_name(product_data.pop('category', None))  # Extract category name from request data

        product_serializer = ProductSerializer(product_instance, data=product_data, partial=True)
        if product_serializer.is_valid():
            product_instance = product_serializer.save()

            if category_name:
                category, _ = Category.objects.get_or_create(category=category_name)
                product_instance.category = category
                product_instance.save()

            return Response(product_serializer.data, status=status.HTTP_200_OK)

        return Response(product_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
@authentication_classes([TokenAuthentication])
@permission_classes([WriteByAdminOnlyPermission])
def deleteProduct(request, pk):
    try:
        product = Product.objects.get(pk=pk)
        product.delete()
        serialized_categories = categoriesSerializer(Category.objects.all(), many=True).data
        data = {
            'categories': serialized_categories
        }
        return Response(data, status=204)
    except Product.DoesNotExist:
        return Response({'message': 'Product does not exist'}, status=404)
