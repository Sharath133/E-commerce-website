from django.contrib import admin
from django.utils.html import format_html
from .models import *
class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'image')
    ordering = ['title']

    def make_action(self, request, category):
        def action(modeladmin, request, queryset):
            queryset.update(category=category)
        action.__name__ = f"mark_as_{category.id}"
        action.short_description = f"Mark selected as {category.category}"
        return action

    def get_actions(self, request):
        actions = super().get_actions(request)
        categories_objs = Category.objects.all()
        for category in categories_objs:
            action_func = self.make_action(request, category)
            actions[action_func.__name__] = (action_func, action_func.__name__, action_func.short_description)
        return actions

    def images(self, obj):
        return format_html('<img src="{0}" width="auto" height="auto">'.format(obj.image.url))

admin.site.register(Product, ProductAdmin)
admin.site.register(Category)
