from django.contrib import admin
from django.utils.html import format_html

from .models import *

class Productadmin(admin.ModelAdmin):
    list_display=('title','description','image')
    def images(self,obj):
        return format_html('<img src ="{0}" width ="auto " height ="auto" >'.format(obj.image.url))

admin.site.register(Product,Productadmin)
# Register your models here.