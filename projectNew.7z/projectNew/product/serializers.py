from rest_framework import serializers
from django.contrib.sites.shortcuts import get_current_site
from django.urls import reverse
from .models import *
from django.contrib.auth.models import User

# User Serializer
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email')

# Register Serializer
class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(validated_data['username'], validated_data['email'], validated_data['password'])

        return user
    


class categoriesSerializer(serializers.ModelSerializer):
    class Meta:
        model = categories
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    category = categoriesSerializer(required=False)# Add read_only=True to exclude categoryId
    
    def to_representation(self, instance):
        representation=super().to_representation(instance)
        category = representation.get('category')
        if category:
            representation['category']=representation['category'].get('category','').strip("'\",[]")
        return representation

    class Meta:
        model = Product
        fields = '__all__'  # Exclude the categoryId field
