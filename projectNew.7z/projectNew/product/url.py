from django.urls import path, include
from .views import *
from rest_framework import routers
# from rest_framework.authtoken.views import obtain_auth_token
from django.conf.urls.static import static
from django.conf import settings
from . import views
from product.views import LoginAPI,RegisterAPI
from django.urls import path
from rest_framework import status
from rest_framework.views import APIView


urlpatterns = [
    path('register', RegisterAPI.as_view(), name='register'),
    path('login', LoginAPI.as_view(), name='login'),
    # path('search', search.as_view(), name='search'),
    path('products', views.getProducts), 
    path('products/create', views.ImageView.as_view({'post': 'create'})), 
    path('products/<str:pk>', views.getProduct), 
    path('products/update/<str:pk>', views.ImageView.as_view({'put': 'update'})),
    path('products/delete/<str:pk>', views.deleteProduct),  

] + static(settings.MEDIA_URL ,document_root=settings.MEDIA_ROOT)
